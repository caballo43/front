import React from "react";


const Cursos = () => {
  return <div>Gestión de Cursos</div>;
};

export default Cursos;
