import React from 'react';

const Usuarios = () => {
	return <div>Gestión de Usuarios</div>;
};

export default Usuarios;
