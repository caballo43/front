import React from "react";

const Error = () => {
  return (
    <div>
      <h1>Error 404. Página no encontrada</h1>
    </div>
  );
};

export default Error;
