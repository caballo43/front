import React from 'react';


const Inicio = () => {
	return (
		<div>
			<div class="intro"><img src="./img/sixflix.jpg" alt="" /></div>
			<h2>Lo último</h2>

			<div>
				<section class="slider_container">
					<section class="slider">
						<div class="slide one">
							<img src="https://www.loslunesseriefilos.com/wp-content/uploads/2023/01/critica-megan-peli.jpg" alt="" />

							<span class="caption">

							</span>
						</div>
						<div class="slide two">
							<img src="https://allears.net/wp-content/uploads/2023/04/guardians-of-the-galaxy-vol-3-image.png" alt="" />
							<span class="caption">

							</span>
						</div>
						<div class="slide three">
							<img src="https://media.revistavanityfair.es/photos/60e850a8bf8d45dd8c6f79ad/master/w_1600%2Cc_limit/3105.jpg" alt="" />
							<span class="caption">

							</span>
						</div>


					</section>
				</section>






			</div>
		</div >
	);
};

export default Inicio;
